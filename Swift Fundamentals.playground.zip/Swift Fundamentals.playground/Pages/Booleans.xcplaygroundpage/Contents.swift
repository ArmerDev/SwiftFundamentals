/*: # Booleans*/
import Foundation
/*:Swift uses the type Bool to store true or false:*/
let goodDogs = true
let gameOver = false
/*:You can flip a Boolean from true to false by calling its toggle() method:*/
var isSaved = false
isSaved.toggle()
