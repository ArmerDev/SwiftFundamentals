/*: # Doubles*/
import Foundation
/*:If you create a number with a decimal point, Swift will consider it a Double:*/
let score = 3.0
/*:Swift considers Double to be a wholly different data type to Int, and won't let you mix them together.*/
